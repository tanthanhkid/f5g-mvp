'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { useAuth } from '@/contexts/AuthContext';
import { BookOpen, Brain, Calculator, Globe, Beaker, Palette, Music, Code, Heart, Leaf, ArrowLeft, Play } from 'lucide-react';
import LoadingOverlay from '@/components/LoadingOverlay';

interface QuizTopic {
  id: string;
  name: string;
  description: string;
  icon: React.ComponentType<{ className?: string }>;
  color: string;
  difficulty: 'Dễ' | 'Trung bình' | 'Khó';
  questionCount: number;
  estimatedTime: number; // phút
}

export default function QuizTopicsPage() {
  const { user } = useAuth();
  const router = useRouter();
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    if (!user) {
      router.push('/login');
      return;
    }
  }, [user, router]);

  const quizTopics: QuizTopic[] = [
    {
      id: 'general-knowledge',
      name: 'Kiến thức tổng quát',
      description: 'Các câu hỏi về văn hóa, lịch sử, địa lý và thời sự',
      icon: BookOpen,
      color: 'bg-blue-500 text-white',
      difficulty: 'Trung bình',
      questionCount: 10,
      estimatedTime: 5
    },
    {
      id: 'mathematics',
      name: 'Toán học',
      description: 'Đại số, hình học, giải tích và thống kê',
      icon: Calculator,
      color: 'bg-green-500 text-white',
      difficulty: 'Khó',
      questionCount: 8,
      estimatedTime: 8
    },
    {
      id: 'science',
      name: 'Khoa học tự nhiên',
      description: 'Vật lý, hóa học, sinh học và khoa học trái đất',
      icon: Beaker,
      color: 'bg-purple-500 text-white',
      difficulty: 'Khó',
      questionCount: 10,
      estimatedTime: 6
    },
    {
      id: 'technology',
      name: 'Công nghệ thông tin',
      description: 'Lập trình, mạng máy tính, AI và công nghệ mới',
      icon: Code,
      color: 'bg-indigo-500 text-white',
      difficulty: 'Trung bình',
      questionCount: 12,
      estimatedTime: 7
    },
    {
      id: 'english',
      name: 'Tiếng Anh',
      description: 'Ngữ pháp, từ vựng, đọc hiểu và giao tiếp',
      icon: Globe,
      color: 'bg-red-500 text-white',
      difficulty: 'Trung bình',
      questionCount: 15,
      estimatedTime: 10
    },
    {
      id: 'arts',
      name: 'Nghệ thuật',
      description: 'Hội họa, điêu khắc, kiến trúc và nghệ thuật đương đại',
      icon: Palette,
      color: 'bg-pink-500 text-white',
      difficulty: 'Dễ',
      questionCount: 8,
      estimatedTime: 4
    },
    {
      id: 'music',
      name: 'Âm nhạc',
      description: 'Lý thuyết âm nhạc, nhạc cụ và các thể loại nhạc',
      icon: Music,
      color: 'bg-yellow-500 text-white',
      difficulty: 'Dễ',
      questionCount: 10,
      estimatedTime: 5
    },
    {
      id: 'health',
      name: 'Sức khỏe',
      description: 'Y học, dinh dưỡng, thể dục và chăm sóc sức khỏe',
      icon: Heart,
      color: 'bg-rose-500 text-white',
      difficulty: 'Trung bình',
      questionCount: 12,
      estimatedTime: 6
    },
    {
      id: 'environment',
      name: 'Môi trường',
      description: 'Bảo vệ môi trường, biến đổi khí hậu và phát triển bền vững',
      icon: Leaf,
      color: 'bg-emerald-500 text-white',
      difficulty: 'Trung bình',
      questionCount: 10,
      estimatedTime: 5
    }
  ];

  const handleBackToDashboard = async () => {
    setIsLoading(true);
    await new Promise(resolve => setTimeout(resolve, 800));
    router.push('/dashboard');
  };

  const handleSelectTopic = async (topicId: string) => {
    setIsLoading(true);
    await new Promise(resolve => setTimeout(resolve, 1000));
    // Chuyển đến trang quiz với topic được chọn
    router.push(`/quiz?topic=${topicId}`);
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'Dễ': return 'bg-green-100 text-green-800';
      case 'Trung bình': return 'bg-yellow-100 text-yellow-800';
      case 'Khó': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">Đang tải...</p>
        </div>
      </div>
    );
  }

  return (
    <>
      <LoadingOverlay isVisible={isLoading} message="Đang tải chủ đề..." />
      <div className="min-h-screen bg-gray-50">
        {/* Header */}
        <div className="bg-white shadow-sm border-b">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex justify-between items-center py-4">
              <div className="flex items-center space-x-3">
                <button
                  onClick={handleBackToDashboard}
                  className="p-2 text-gray-500 hover:text-gray-700 hover:bg-gray-100 rounded-lg transition-colors"
                >
                  <ArrowLeft className="w-5 h-5" />
                </button>
                <button 
                  onClick={() => router.push('/')}
                  className="flex items-center space-x-3 hover:opacity-80 transition-opacity"
                >
                  <div className="w-10 h-10 rounded-lg overflow-hidden">
                    <img 
                      src="/17164524823262_logo-web-con-voi.png" 
                      alt="Freedom Training Logo" 
                      className="w-full h-full object-contain"
                    />
                  </div>
                  <div>
                    <h1 className="text-2xl font-bold text-gray-900">Chọn chủ đề Quiz</h1>
                    <p className="text-sm text-gray-600">Chọn chủ đề bạn muốn thử thách</p>
                  </div>
                </button>
              </div>
              
              <div className="text-right">
                <p className="text-sm font-medium text-gray-900">{user.name}</p>
                <p className="text-xs text-gray-600">{user.tutePoints} điểm TUTE</p>
              </div>
            </div>
          </div>
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {/* Welcome Section */}
          <div className="bg-gradient-to-r from-blue-600 to-indigo-600 rounded-2xl p-8 text-white mb-8">
            <div className="text-center">
              <Brain className="w-16 h-16 mx-auto mb-4 opacity-90" />
              <h2 className="text-3xl font-bold mb-2">Thử thách trí tuệ</h2>
              <p className="text-blue-100 text-lg">
                Chọn chủ đề yêu thích và bắt đầu hành trình tích lũy điểm TUTE
              </p>
            </div>
          </div>

          {/* Topics Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {quizTopics.map((topic) => {
              const IconComponent = topic.icon;
              return (
                <div
                  key={topic.id}
                  className="bg-white rounded-xl shadow-sm border hover:shadow-lg transition-all duration-300 hover:scale-105 cursor-pointer"
                  onClick={() => handleSelectTopic(topic.id)}
                >
                  <div className="p-6">
                    {/* Icon và tiêu đề */}
                    <div className="flex items-center space-x-4 mb-4">
                      <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${topic.color}`}>
                        <IconComponent className="w-6 h-6" />
                      </div>
                      <div className="flex-1">
                        <h3 className="text-xl font-bold text-gray-900">{topic.name}</h3>
                        <span className={`inline-block px-2 py-1 rounded-full text-xs font-medium ${getDifficultyColor(topic.difficulty)}`}>
                          {topic.difficulty}
                        </span>
                      </div>
                    </div>

                    {/* Mô tả */}
                    <p className="text-gray-600 mb-4 text-sm leading-relaxed">
                      {topic.description}
                    </p>

                    {/* Thông tin quiz */}
                    <div className="flex justify-between items-center text-sm text-gray-500 mb-4">
                      <span>{topic.questionCount} câu hỏi</span>
                      <span>~{topic.estimatedTime} phút</span>
                    </div>

                    {/* Nút bắt đầu */}
                    <button className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 text-white py-3 rounded-lg font-semibold hover:from-blue-700 hover:to-indigo-700 transition-all flex items-center justify-center space-x-2">
                      <Play className="w-4 h-4" />
                      <span>Bắt đầu Quiz</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Thông tin bổ sung */}
          <div className="mt-12 bg-white rounded-xl p-6 shadow-sm border">
            <div className="text-center">
              <h3 className="text-xl font-bold text-gray-900 mb-2">Cách tính điểm TUTE</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-6">
                <div className="text-center">
                  <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-2">
                    <span className="text-green-600 font-bold">+10</span>
                  </div>
                  <p className="text-sm text-gray-600">Câu trả lời đúng (Dễ)</p>
                </div>
                <div className="text-center">
                  <div className="w-12 h-12 bg-yellow-100 rounded-full flex items-center justify-center mx-auto mb-2">
                    <span className="text-yellow-600 font-bold">+15</span>
                  </div>
                  <p className="text-sm text-gray-600">Câu trả lời đúng (Trung bình)</p>
                </div>
                <div className="text-center">
                  <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-2">
                    <span className="text-red-600 font-bold">+20</span>
                  </div>
                  <p className="text-sm text-gray-600">Câu trả lời đúng (Khó)</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
} 