'use client';

import { useRouter } from 'next/navigation';
import { BookOpen, Trophy, Users, ArrowRight, Calendar } from 'lucide-react';
import { useEffect, useState } from 'react';

export default function HomePage() {
  const router = useRouter();
  const [currentDate, setCurrentDate] = useState('');

  useEffect(() => {
    const today = new Date();
    setCurrentDate(today.toLocaleDateString('vi-VN', { 
      weekday: 'long', 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric' 
    }));
  }, []);

  const handleLearnToEarn = () => {
    router.push('/login');
  };

  // Tính toán số tiền tài trợ hôm nay (giả lập)
  const totalPool = 1000000000; // 1 tỷ VND
  const dailySponsorship = 2740000; // ~2.74 triệu VND/ngày (1 tỷ / 365 ngày)
  const usedToday = Math.floor(Math.random() * dailySponsorship * 0.3); // Đã sử dụng trong ngày
  const remainingToday = dailySponsorship - usedToday;
  const totalRemaining = totalPool - (Math.floor(Math.random() * totalPool * 0.15)); // Còn lại tổng

  const majorSponsors = [
    { 
      name: 'Bảo hiểm Dai-ichi Life', 
      logo: '/company_logo/logo-dai-ichi-life-png-clipart.png',
      amount: '250 triệu VND',
      color: 'border-blue-200 hover:border-blue-400'
    },
    { 
      name: 'Ngân hàng Eximbank', 
      logo: '/company_logo/PNG-FILE-NganHang-Eximbank.jpg',
      amount: '250 triệu VND',
      color: 'border-green-200 hover:border-green-400'
    },
    { 
      name: 'Vinamilk', 
      logo: '/company_logo/Logo_Vinamilk_(2023).png',
      amount: '250 triệu VND',
      color: 'border-blue-200 hover:border-blue-400'
    },
    { 
      name: 'Nutifood', 
      logo: '/company_logo/nutifood-compressed.jpg',
      amount: '250 triệu VND',
      color: 'border-emerald-200 hover:border-emerald-400'
    }
  ];

  const minorSponsors = [
    'FPT Software', 'Viettel', 'VNPT', 'Mobifone', 'Techcombank', 'VPBank',
    'Sacombank', 'ACB', 'VietinBank', 'BIDV', 'Agribank', 'MB Bank',
    'Tiki', 'Shopee', 'Lazada', 'Grab', 'Be Group', 'VNG Corporation',
    'Masan Group', 'Vingroup'
  ];

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('vi-VN', {
      style: 'currency',
      currency: 'VND',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 rounded-lg overflow-hidden">
                <img 
                  src="/17164524823262_logo-web-con-voi.png" 
                  alt="Freedom Training Logo" 
                  className="w-full h-full object-contain"
                />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">Freedom Training</h1>
                <p className="text-sm text-gray-600">Nền tảng học tập trực tuyến</p>
              </div>
            </div>
            <button
              onClick={handleLearnToEarn}
              className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white px-6 py-2 rounded-lg font-medium hover:from-blue-700 hover:to-indigo-700 transition-all"
            >
              Đăng nhập
            </button>
          </div>
        </div>
      </div>

      {/* Hero Section với vòng tròn thông báo */}
      <div className="relative overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <div className="text-center">
            <h1 className="text-5xl md:text-6xl font-bold text-gray-900 mb-6">
              Freedom Training
            </h1>
            <p className="text-xl md:text-2xl text-gray-600 mb-8 max-w-3xl mx-auto">
              Nền tảng học tập trực tuyến với hệ thống phần thưởng TUTE độc đáo
            </p>
            
            {/* Thông báo số tiền và nhà tài trợ */}
            <div className="max-w-6xl mx-auto mb-12">
              {/* Vòng tròn thông báo số tiền */}
              <div className="relative w-80 h-80 mx-auto mb-12">
                <div className="absolute inset-0 bg-gradient-to-r from-yellow-400 via-orange-500 to-red-500 rounded-full animate-pulse"></div>
                <div className="absolute inset-2 bg-white rounded-full flex flex-col items-center justify-center p-8">
                  <div className="text-center">
                    <div className="flex items-center justify-center mb-2">
                      <Calendar className="w-6 h-6 text-orange-500 mr-2" />
                      <p className="text-sm font-medium text-gray-600">{currentDate}</p>
                    </div>
                    <h3 className="text-lg font-bold text-gray-900 mb-2">Tài trợ hôm nay</h3>
                    <div className="text-3xl font-bold text-orange-600 mb-1">
                      {formatCurrency(dailySponsorship)}
                    </div>
                    <div className="text-sm text-gray-500 mb-3">
                      Còn lại: <span className="font-semibold text-green-600">{formatCurrency(remainingToday)}</span>
                    </div>
                    <div className="border-t pt-3">
                      <p className="text-xs text-gray-500 mb-1">Tổng pool còn lại</p>
                      <div className="text-xl font-bold text-blue-600">
                        {formatCurrency(totalRemaining)}
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Cards nhà tài trợ chính */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
                {majorSponsors.map((sponsor, index) => (
                  <div
                    key={index}
                    className={`bg-white rounded-xl p-4 shadow-sm border-2 ${sponsor.color} hover:shadow-lg transition-all duration-300 hover:scale-105`}
                  >
                    <div className="text-center">
                      {/* Logo container */}
                      <div className="w-16 h-16 md:w-20 md:h-20 mx-auto mb-3 bg-gray-50 rounded-lg overflow-hidden flex items-center justify-center p-2">
                        <img 
                          src={sponsor.logo} 
                          alt={`${sponsor.name} logo`}
                          className="max-w-full max-h-full object-contain"
                        />
                      </div>
                      
                      {/* Tên công ty */}
                      <h3 className="font-bold text-gray-900 mb-2 text-xs md:text-sm leading-tight">
                        {sponsor.name === 'Bảo hiểm Dai-ichi Life' ? 'Dai-ichi Life' :
                         sponsor.name === 'Ngân hàng Eximbank' ? 'Eximbank' :
                         sponsor.name === 'Vinamilk' ? 'Vinamilk' :
                         sponsor.name === 'Nutifood' ? 'Nutifood' : sponsor.name}
                      </h3>
                      
                      {/* Số tiền tài trợ */}
                      <div className="bg-gradient-to-r from-green-500 to-emerald-500 text-white px-2 py-1 rounded-full text-xs font-semibold">
                        {sponsor.amount}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <button
              onClick={handleLearnToEarn}
              className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white px-12 py-4 rounded-xl text-xl font-bold hover:from-blue-700 hover:to-indigo-700 transition-all transform hover:scale-105 shadow-lg flex items-center mx-auto"
            >
              <span>Learn to Earn</span>
              <ArrowRight className="w-6 h-6 ml-2" />
            </button>
          </div>
        </div>
      </div>

      {/* Features Section */}
      <div className="bg-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Tại sao chọn Freedom Training?</h2>
            <p className="text-xl text-gray-600">Học tập thông minh, kiếm tiền thực tế</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center p-6">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <BookOpen className="w-8 h-8 text-blue-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Học tập hiệu quả</h3>
              <p className="text-gray-600">Hệ thống quiz đa dạng với nhiều chủ đề khác nhau, phù hợp với sinh viên các trường đại học</p>
            </div>
            
            <div className="text-center p-6">
              <div className="w-16 h-16 bg-yellow-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Trophy className="w-8 h-8 text-yellow-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Tích lũy điểm TUTE</h3>
              <p className="text-gray-600">Mỗi câu trả lời đúng sẽ được cộng điểm TUTE, tích lũy để nhận phần thưởng giá trị</p>
            </div>
            
            <div className="text-center p-6">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Users className="w-8 h-8 text-green-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Thi đua giữa các trường</h3>
              <p className="text-gray-600">Cạnh tranh lành mạnh giữa các trường đại học, tạo động lực học tập</p>
            </div>
          </div>
        </div>
      </div>

       

      {/* Minor Sponsors */}
      <div className="bg-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Nhà Tài Trợ Đồng Hành</h2>
            <p className="text-gray-600">Cùng nhiều doanh nghiệp khác tại Việt Nam</p>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-4">
            {minorSponsors.map((sponsor, index) => (
              <div key={index} className="bg-gray-50 rounded-lg p-4 text-center hover:bg-gray-100 transition-colors">
                <p className="text-sm font-medium text-gray-700">{sponsor}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* CTA Section */}
      <div className="bg-gradient-to-r from-blue-600 to-indigo-700 py-16">
        <div className="max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
            Sẵn sàng bắt đầu hành trình Learn to Earn?
          </h2>
          <p className="text-xl text-blue-100 mb-8">
            Tham gia ngay để tích lũy điểm TUTE và nhận phần thưởng giá trị
          </p>
          <button
            onClick={handleLearnToEarn}
            className="bg-white text-blue-600 px-8 py-4 rounded-xl text-lg font-bold hover:bg-blue-50 transition-all transform hover:scale-105 shadow-lg"
          >
            Bắt đầu ngay
          </button>
        </div>
      </div>

      {/* Footer */}
      <div className="bg-gray-900 py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center space-x-3 mb-4 md:mb-0">
              <div className="w-8 h-8 rounded-lg overflow-hidden">
                <img 
                  src="/17164524823262_logo-web-con-voi.png" 
                  alt="Freedom Training Logo" 
                  className="w-full h-full object-contain"
                />
              </div>
              <div>
                <h3 className="text-white font-semibold">Freedom Training</h3>
                <p className="text-gray-400 text-sm">Learn to Earn Platform</p>
              </div>
            </div>
            <p className="text-gray-400 text-sm">
              © 2024 Freedom Training. Tất cả quyền được bảo lưu.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
